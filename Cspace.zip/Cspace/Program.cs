﻿using Cspace.ConsoleUI; MainMenu mainMenu = new MainMenu(); mainMenu.Display();
